"""Compare exact original IDs and Unicode-character BIO tags, without source text."""
import argparse,hashlib,json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent/'src'))
from validate_predictions import strict_json,labels
def compare(reference,candidate):
    a=Path(reference).read_bytes();b=Path(candidate).read_bytes();left=strict_json(a);right=strict_json(b)
    issues=[];sentences=characters=changed_sentences=changed_tags=0
    if set(left)!=set(right):issues.append({'kind':'dialogue_id_set','missing':sorted(set(left)-set(right)),'extra':sorted(set(right)-set(left))})
    for did in sorted(set(left)&set(right)):
        if set(left[did])!=set(right[did]):issues.append({'kind':'sentence_id_set','dialogue_id':did,'missing':sorted(set(left[did])-set(right[did])),'extra':sorted(set(right[did])-set(left[did]))})
        for sid in sorted(set(left[did])&set(right[did])):
            x=labels(left[did][sid]);y=labels(right[did][sid]);sentences+=1;characters+=len(x)
            if len(x)!=len(y):issues.append({'kind':'length','dialogue_id':did,'sentence_id':sid,'reference':len(x),'candidate':len(y)})
            mismatch=[i for i,(u,v) in enumerate(zip(x,y)) if u!=v];changed_tags+=len(mismatch)+abs(len(x)-len(y))
            if x!=y:
                changed_sentences+=1
                if len(issues)<30:issues.append({'kind':'tag_difference','dialogue_id':did,'sentence_id':sid,'positions':mismatch[:30]})
    return {'status':'IDENTICAL' if not issues and not changed_sentences else 'DIFFERENT','reference':str(Path(reference).resolve()),'candidate':str(Path(candidate).resolve()),'reference_sha256':hashlib.sha256(a).hexdigest(),'candidate_sha256':hashlib.sha256(b).hexdigest(),'byte_identical':a==b,'dialogues_compared':len(set(left)&set(right)),'sentences_compared':sentences,'character_tags_compared':characters,'changed_sentences':changed_sentences,'changed_character_tags':changed_tags,'differences':issues,'comparison_policy':'exact dialogue/sentence IDs; original character-index tag equality; no text, normalization, relabeling or repair'}
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--reference',required=True);p.add_argument('--candidate',required=True);p.add_argument('--report',required=True);a=p.parse_args();r=compare(a.reference,a.candidate)
    with Path(a.report).open('x',encoding='utf-8') as f:json.dump(r,f,ensure_ascii=False,indent=2);f.write('\n')
    print(json.dumps(r,ensure_ascii=False));sys.exit(0 if r['status']=='IDENTICAL' else 1)
