"""Verify controlled assets and provision a portable root without editing frozen code."""
import argparse,hashlib,json,shutil,zipfile
from pathlib import Path
HERE=Path(__file__).resolve().parent
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
    return h.hexdigest()
def write(p,v):
    p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,ensure_ascii=False,indent=2,allow_nan=False);f.write('\n')
def provision(assets_dir,archive,root,split,output_config,run_id):
    assets_dir=Path(assets_dir).resolve();root=Path(root).resolve();archive=Path(archive).resolve()
    expected=read(HERE.parent/'model/required_assets.json')
    actual=read(assets_dir/'assets_manifest.json')
    if actual['files']!=expected['files']:raise ValueError('controlled asset manifest differs from frozen requirements')
    if sha(archive)!='84e34d2417b839d9fbe5c5f391e44de2a9b01bd5f31d576b8feccc78c1dfbc67':raise ValueError('original archive identity mismatch')
    installed=[]
    for name,info in expected['files'].items():
        source=(assets_dir/name).resolve();target=(root/info['project_relative_path']).resolve()
        if not source.is_relative_to(assets_dir) or not target.is_relative_to(root):raise ValueError('asset path escapes allowed root')
        if source.stat().st_size!=info['bytes'] or sha(source)!=info['sha256']:raise ValueError('asset identity mismatch: '+name)
        target.parent.mkdir(parents=True,exist_ok=True)
        if target.exists():
            if sha(target)!=info['sha256']:raise ValueError('refuse overwriting different existing asset: '+name)
        else:shutil.copyfile(source,target)
        if sha(target)!=info['sha256']:raise ValueError('provisioned identity mismatch: '+name)
        installed.append({'asset':name,'project_relative_path':info['project_relative_path'],'sha256':info['sha256'],'bytes':info['bytes']})
    original_path=HERE.parent/split/'config/inference.json';original=read(original_path)
    source_relative='controlled_inputs/IMCS-V2_'+split+'.json'
    with zipfile.ZipFile(archive) as z:raw=z.read('IMCS-V2-NER/IMCS-V2_'+split+'.json')
    if hashlib.sha256(raw).hexdigest()!=original['source_sha256']:raise ValueError('source JSON identity mismatch')
    dest=root/source_relative;dest.parent.mkdir(parents=True,exist_ok=True)
    if dest.exists():
        if sha(dest)!=original['source_sha256']:raise ValueError('refuse overwriting a different source JSON')
    else:
        with dest.open('xb') as f:f.write(raw)
    adapted={**original,'source':source_relative,'run_id':run_id}
    diff={k:{'original':original[k],'adapted':adapted[k]} for k in original if original[k]!=adapted[k]}
    if set(diff)-{'source','run_id'}:raise ValueError('adaptation changed a frozen model/asset field')
    output_config=Path(output_config).resolve();write(output_config,adapted)
    report={'status':'PASS','project_root':str(root),'assets':installed,'source_file':source_relative,'source_sha256':original['source_sha256'],'archive_sha256':sha(archive),'original_config':str(original_path),'original_config_sha256':sha(original_path),'adapted_config':str(output_config),'adapted_config_sha256':sha(output_config),'differences':diff,'frozen_training_config_sha256':sha(HERE/'training_config.json'),'pretrained_weights_required':False,'frozen_infer_modified':False,'note':'Only path and run identity adapted; tokenizer/pretrained config retain frozen relative layout under user-selected project root.'}
    write(output_config.with_suffix('.paths.json'),report)
    return report
def main():
    p=argparse.ArgumentParser();p.add_argument('--assets-dir',required=True);p.add_argument('--data-archive',required=True);p.add_argument('--project-root',required=True);p.add_argument('--split',choices=('dev','test'),required=True);p.add_argument('--output-config',required=True);p.add_argument('--run-id',required=True);a=p.parse_args()
    print(json.dumps(provision(a.assets_dir,a.data_archive,a.project_root,a.split,a.output_config,a.run_id),ensure_ascii=False))
if __name__=='__main__':main()
