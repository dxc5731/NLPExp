# E5 冻结版本复现与校验（v1.1）

本次正式模型始终是第三轮 E5：训练 run `20261021T195736+0800_real_training_95abb833`，原受评 dev run `20261022T205207+0800_frozen_e5_dev`。第四轮 Boundary Auxiliary 是另一模型，不能用于本包复现。

`infer.py`、`src/bert_crf/` 和 `training_config.json` 均与 v1.0 冻结包逐字节一致；模型、Tokenizer、字符映射、CRF 解码和资产哈希没有修改。新增的 prepare_assets.py 只准备独立项目根及另存路径配置，不修改冻结入口和训练逻辑。

## 1. 受控取得模型资产

请向模型负责人 dxc5731 索取 `PRIVATE-BERT-CRF-E5-Controlled-Assets_20261023T232759+0800.zip`，由负责人通过组内点对点传输或当面移动存储私下交付。该文件已在负责人本机准备，但生成本说明时尚未向组员发送，没有公开权重下载地址。接收后核对 ZIP SHA-256：`1c54390b277adec11dbd36d92b25c8c11ba7b374496afc43b4a7b6e38188aa4b`，大小 1220894004 字节。解压后使用其中 `PRIVATE-BERT-CRF-E5-Controlled-Assets/` 目录作为 `--assets-dir`。

原始 E5 Checkpoint 必须为 1,220,509,451 字节，SHA-256 `e5ee6aaa8d4a00a4626553002aa9a63253a8ee0139463fec2bb41427bf391bed`。不要用重导出模型、第四轮 Checkpoint 或预训练 BERT 权重代替。受控包含完整原始 Checkpoint、四个 Tokenizer 文件和 pretrained/config.json；不含原始医疗数据。

## 2. 相对于 --project-root 的资产位置

`--project-root` 是受控模型/数据根，和本交接包解压目录可以不同。冻结原配置所用位置如下；表中每个文件都已在本机重新核验。

| 相对项目根路径 | 字节 | SHA-256 |
|---|---:|---|
| `experiments/bert_crf/20261021T195736+0800_real_training_95abb833/checkpoints/epoch_0005.pt` | 1220509451 | `e5ee6aaa8d4a00a4626553002aa9a63253a8ee0139463fec2bb41427bf391bed` |
| `.local/bert_crf/20261019T162653+0800_stage1a/tokenizer/config.json` | 624 | `88af762cfb15fa9ce183c84dcbfdc9d635196ba635dfe81f265fdd21d67f4c4c` |
| `.local/bert_crf/20261019T162653+0800_stage1a/tokenizer/tokenizer.json` | 268943 | `55c5edcfb8936895e019b2d8f97dcb547734f25b29f95009155f4c8c15649aae` |
| `.local/bert_crf/20261019T162653+0800_stage1a/tokenizer/tokenizer_config.json` | 49 | `0f6d13e6f4da6f9e24f22ada6bc3be571123d858d7c0c05a8a7cd55a9c23c2e8` |
| `.local/bert_crf/20261019T162653+0800_stage1a/tokenizer/vocab.txt` | 109540 | `45bbac6b341c319adc98a532532882e91a9cefc0329aa57bac9ae761c27b291c` |
| `.local/bert_crf/20261019T174356+0800_stage1b/pretrained/config.json` | 624 | `88af762cfb15fa9ce183c84dcbfdc9d635196ba635dfe81f265fdd21d67f4c4c` |
| `docs/bert_crf/evidence/20261022T205207+0800_final_dev_test_handoff/data/IMCS-V2_dev.json` | 17175331 | `16f597ad368971c7db994ca904e05d91942f0e3c73009c9ef1d597fde065d39f` |

原 test 配置 source 为 `docs/bert_crf/evidence/20261022T205207+0800_final_dev_test_handoff/data/IMCS-V2_test.json`，SHA-256 `46ee2e8bbffdc722cad7b813e5d8223c5842904924a164faaf0db523e7c0f09d`。

异机推荐使用下面的资产准备命令：它在你指定的新项目根下准备完全相同的 checkpoint/tokenizer/pretrained 配置相对位置，将合法持有的固定官方 ZIP 中的原始 JSON 按字节提取到 `controlled_inputs/IMCS-V2_dev.json` 或 `controlled_inputs/IMCS-V2_test.json`，并另存 inference.adapted.json 及 inference.adapted.paths.json。与原推理配置只允许 `source`、`run_id` 两个字段不同，原配置保留。模型参数、资产哈希和 training_config.json 不改。

**不需要预训练权重本体**。入口仅从 pretrained/config.json 构造结构，然后从完整 E5 Checkpoint 严格加载全部模型状态；不调用预训练权重下载。原机这次使用的独立项目根下 pretrained 目录只有 config.json，并已完整重推理成功，见 evidence/no_pretrained_weights.json。

## 3. CUDA 与安装环境

冻结入口内部固定使用 `cuda`，本版本没有 CPU 推理回退。评分器和格式校验器可用 CPU，但模型重推理必须先有可用 CUDA。原机成功环境：Windows 11 x64，Python 3.13.5（Anaconda 构建），PyTorch 2.14.1+cu132，CUDA runtime 13.2，cuDNN 92400，Transformers 5.20.1，Tokenizers 0.23.3；NVIDIA GeForce RTX 5060 Laptop GPU，驱动 595.79。

requirements.lock.txt 原有 7 项固定版本与本次成功环境全部匹配；requirements.full.lock.txt 为本次实际 pip freeze --all。installation_sources.json 保留原成功安装报告中的来源及 wheel SHA。本轮复用了现有环境，没有声称重新安装一个全新环境。下面是针对 **Windows x64 + CPython 3.13.5** 的安装步骤；其他系统不能直接使用该 Windows wheel。

```powershell
New-Item -ItemType Directory -Force C:/controlled
py -3.13 -m venv .venv-e5-repro
.venv-e5-repro/Scripts/python.exe --version
.venv-e5-repro/Scripts/python.exe -m pip install "https://download-r2.pytorch.org/whl/cu132/torch-2.14.1%2Bcu132-cp313-cp313-win_amd64.whl#sha256=4d682f3fc2911a6d6538a340a23e2372ae539acae1b6b50f3299214021386860"
.venv-e5-repro/Scripts/python.exe -m pip install -r reproduce/requirements.lock.txt
.venv-e5-repro/Scripts/python.exe -m pip check
.venv-e5-repro/Scripts/python.exe -X utf8 reproduce/check_environment.py --report C:/controlled/environment_check.json
```

安装前确认 `py -3.13` 实际为 3.13.5；这不是自动安装 Python 的命令。PyTorch wheel 来源取自原安装报告，本次 HEAD 请求返回 200，见 evidence/torch_wheel_endpoint.json。NVIDIA 驱动须支持该 CUDA runtime；不通过 CUDA 探针时停止，不用 CPU 或另一套权重冒充复现。原机探针、锁定版本核验和本次实际完整推理均通过；不据此声称所有异机驱动已验证。无需另外为本入口下载 BERT 预训练权重或单独安装 CUDA 编译工具链。

## 4. 新预测 → 新校验 → 统一评分 → 新旧比较

以下在**本包根目录**运行，`python` 必须指向前面已验证的 CUDA 环境。先把受控资产包解压到 C:/controlled；官方原始 ZIP 由评估者合法持有，固定 SHA-256 `84e34d2417b839d9fbe5c5f391e44de2a9b01bd5f31d576b8feccc78c1dfbc67`。所有输出文件须不存在，重跑请更换目录与 run_id。准备脚本会拒绝覆盖哈希不同的旧资产。

```powershell
python -X utf8 reproduce/prepare_assets.py --assets-dir C:/controlled/PRIVATE-BERT-CRF-E5-Controlled-Assets --data-archive C:/controlled/IMCS-V2-NER.zip --project-root C:/controlled/e5_project --split dev --run-id YOUR_UNIQUE_E5_DEV_RUN --output-config C:/controlled/new_dev_output/config/inference.adapted.json
python -u -X utf8 reproduce/infer.py --config C:/controlled/new_dev_output/config/inference.adapted.json --project-root C:/controlled/e5_project --output C:/controlled/new_dev_output
python -X utf8 reproduce/unified_evaluation/src/validate_predictions.py --data C:/controlled/e5_project/controlled_inputs/IMCS-V2_dev.json --predictions C:/controlled/new_dev_output/predictions_dev.json --split dev --report C:/controlled/new_dev_output/validation_dev.json
python -X utf8 reproduce/unified_evaluation/src/evaluate_predictions.py --data C:/controlled/e5_project/controlled_inputs/IMCS-V2_dev.json --predictions C:/controlled/new_dev_output/predictions_dev.json --split dev --purpose model_evaluation --output-dir C:/controlled/new_dev_output/unified_score
python -X utf8 reproduce/compare_predictions.py --reference dev/predictions_dev.json --candidate C:/controlled/new_dev_output/predictions_dev.json --report C:/controlled/new_dev_output/prediction_comparison.json
```

注意校验、评分和比较候选都指向 **C:/controlled/new_dev_output/predictions_dev.json**，不再校验包内旧文件。包内 dev/predictions_dev.json 只用于最后的新旧比较 reference。

test 对应流程（本轮未重新运行 test，只修正流程说明；旧正式 test 预测保留）：

```powershell
python -X utf8 reproduce/prepare_assets.py --assets-dir C:/controlled/PRIVATE-BERT-CRF-E5-Controlled-Assets --data-archive C:/controlled/IMCS-V2-NER.zip --project-root C:/controlled/e5_project --split test --run-id YOUR_UNIQUE_E5_TEST_RUN --output-config C:/controlled/new_test_output/config/inference.adapted.json
python -u -X utf8 reproduce/infer.py --config C:/controlled/new_test_output/config/inference.adapted.json --project-root C:/controlled/e5_project --output C:/controlled/new_test_output
python -X utf8 reproduce/unified_evaluation/src/validate_predictions.py --data C:/controlled/e5_project/controlled_inputs/IMCS-V2_test.json --predictions C:/controlled/new_test_output/predictions_test.json --split test --report C:/controlled/new_test_output/validation_test.json
python -X utf8 reproduce/compare_predictions.py --reference test/predictions_test.json --candidate C:/controlled/new_test_output/predictions_test.json --report C:/controlled/new_test_output/prediction_comparison.json
```

test 没有金标准，不运行 test 效果评分，不声称官方 test F1。

## 5. 原机本轮完整复现证据

新 run `20261023T232759+0800_frozen_e5_dev_reproduction`：833 对话、33267 句、441339 字符，推理耗时 112.787487 秒，退出码 0，格式校验 PASS。完整新预测、run_info、实际配置、路径差异、日志、校验、评分和逐标签比较均在 reproduction_dev/。

统一评分器为仓库 evaluation 分支固定提交 `96ab5974672e842808df20cd007c4c737f90a790` 的原样副本，来源及 SHA 在 unified_evaluation/source_identity.json；不是模型内部 metrics。实体 Micro P=87.57432598%，R=91.19942319%，F1=89.35012050%；TP=21503、FP=3051、FN=2075，与 89.3501% 参考一致。该分数是官方 dev 的本地统一评分，不是训练内部验证集成绩，也不是官方 test 分数。

新旧 33267 句、441339 个标签全部一致，差异句数/标签数均为 0，且文件字节一致，SHA-256 `32001c71c939a2f5f73dfabed044032a1e220548e79b9db7c1c1a1b8e2ac5a4d`。模型状态前后相同，更新/反向次数为 0；不通过 Gold 生成预测。

本包契约/比较测试：在 reproduce 下运行 `python -X utf8 -m unittest discover -s tests -v`，34 项通过。统一评估器测试：在 reproduce/unified_evaluation 下先运行 `python -X utf8 tests/prepare_author_reference.py`（下载固定 SHA 的测试专用作者参考，不随公开包再分发），再运行同样 unittest 命令，138 项通过。一次新比较测试夹具的错误预期及修正已保留，未改比较算法或实际预测。

评分器源码、测试和人工例子保持固定提交字节不变；三份历史说明中的缺失相对链接仅改指向该提交已核验存在的 GitHub 文档，以免附带无关历史产物。差异记在 unified_evaluation/source_identity.json。
