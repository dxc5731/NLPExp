"""Fail explicitly unless the frozen CUDA inference environment is available."""
import argparse,importlib.metadata,json,platform,subprocess,sys
from pathlib import Path
def check(cuda=True):
    import torch
    expected={line.split('==')[0]:line.strip().split('==')[1] for line in (Path(__file__).parent/'requirements.lock.txt').read_text().splitlines() if '==' in line}
    actual={name:importlib.metadata.version(name) for name in expected}
    mismatches={name:{'expected':version,'actual':actual[name]} for name,version in expected.items() if actual[name]!=version}
    available=torch.cuda.is_available();probe=None
    if available:
        with torch.inference_mode():
            x=torch.tensor([1.,2.,3.],device='cuda');probe=float((x*x).sum().cpu());torch.cuda.synchronize()
        if probe!=14.:raise RuntimeError('CUDA tensor probe failed')
    info={'status':'PASS' if available and not mismatches else 'FAIL','python':sys.version,'platform':platform.platform(),'expected_packages':expected,'actual_packages':actual,'mismatches':mismatches,'cuda_available':available,'cuda_runtime':torch.version.cuda,'cudnn':torch.backends.cudnn.version(),'gpu':torch.cuda.get_device_name(0) if available else None,'cuda_tensor_probe':probe,'requires_cuda':True,'cpu_fallback_supported':False,'training_performed':False}
    return info
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--report',required=True);a=p.parse_args();r=check()
    with Path(a.report).open('x',encoding='utf-8') as f:json.dump(r,f,ensure_ascii=False,indent=2);f.write('\n')
    print(json.dumps(r,ensure_ascii=False));sys.exit(0 if r['status']=='PASS' else 1)
