import importlib.util,json,sys,tempfile,unittest
from pathlib import Path
BASE=Path(__file__).resolve().parents[1];sys.path.insert(0,str(BASE))
from compare_predictions import compare
class ComparisonTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup);self.root=Path(self.temp.name);self.a=self.root/'a.json';self.b=self.root/'b.json'
        self.pred={'d':{'01':'O B-Drug I-Drug','07':'B-Symptom'}}
        self.a.write_text(json.dumps(self.pred),encoding='utf-8');self.b.write_text(json.dumps(self.pred),encoding='utf-8')
    def change(self,pred):self.b.write_text(json.dumps(pred),encoding='utf-8')
    def test_identical(self):
        r=compare(self.a,self.b);self.assertEqual(r['status'],'IDENTICAL');self.assertEqual((r['sentences_compared'],r['character_tags_compared']),(2,4))
    def test_serialization_can_differ_without_tag_change(self):
        self.b.write_text(json.dumps(self.pred,indent=2),encoding='utf-8');r=compare(self.a,self.b);self.assertEqual(r['status'],'IDENTICAL');self.assertFalse(r['byte_identical'])
    def test_one_changed_tag(self):
        self.pred['d']['07']='O';self.change(self.pred);r=compare(self.a,self.b);self.assertEqual(r['changed_character_tags'],1);self.assertEqual(r['changed_sentences'],1)
    def test_missing_dialogue(self):self.change({});self.assertEqual(compare(self.a,self.b)['status'],'DIFFERENT')
    def test_changed_original_id(self):self.pred['d']['1']=self.pred['d'].pop('01');self.change(self.pred);self.assertEqual(compare(self.a,self.b)['status'],'DIFFERENT')
    def test_length_difference(self):self.pred['d']['07']='B-Symptom O';self.change(self.pred);self.assertEqual(compare(self.a,self.b)['changed_character_tags'],1)
    def test_duplicate_key_rejected(self):
        self.b.write_text('{"d":{"01":"O","01":"O"}}',encoding='utf-8')
        with self.assertRaises(ValueError):compare(self.a,self.b)
    def test_illegal_bio_rejected(self):
        self.pred['d']['07']='I-Drug';self.change(self.pred)
        with self.assertRaises(ValueError):compare(self.a,self.b)
    def test_invalid_utf8_rejected(self):
        self.b.write_bytes(b'\xff')
        with self.assertRaises(UnicodeDecodeError):compare(self.a,self.b)
class FrozenSourceTests(unittest.TestCase):
    def test_frozen_infer_has_no_path_adapter_edits(self):
        import hashlib
        config=json.loads((BASE.parent/'dev/config/inference.json').read_text())
        for name,expected in config['snapshot_files'].items():self.assertEqual(hashlib.sha256((BASE/name).read_bytes()).hexdigest(),expected)
if __name__=='__main__':unittest.main()
