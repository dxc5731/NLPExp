# 第三轮冻结 E5 dev/test 交接包 v1.1

本版本补齐受控资产取得、完整路径布局、CUDA/安装条件、新预测校验链路，以及一次原设备全量 dev 复现证据。原 v1.0 包和历史结果未覆盖。

正式模型：第三轮 BERT-CRF，LR=1e-5、Dropout=0.1、最佳 Epoch=5；训练 run `20261021T195736+0800_real_training_95abb833`。Checkpoint：1,220,509,451 字节，SHA-256 `e5ee6aaa8d4a00a4626553002aa9a63253a8ee0139463fec2bb41427bf391bed`。冻结 infer.py、模型快照、训练配置均未修改；第四轮边界辅助模型独立，不用于本包。

| 材料 | 目录 | 覆盖 | 状态 |
|---|---|---|---|
| 原正式 dev，20261022T205207+0800_frozen_e5_dev | [dev](dev/run_info.json) | 833 对话／33267 句 | 原样保留 |
| 原正式 test，20261022T205207+0800_frozen_e5_test | [test](test/run_info.json) | 811 对话／32935 句 | 原样保留，本轮未重新运行 |
| 本次全新 dev 复现，20261023T232759+0800_frozen_e5_dev_reproduction | [reproduction_dev](reproduction_dev/run_info.json) | 833 对话／33267 句／441339 字符 | PASS，退出码 0 |

新旧 dev 逐 ID、逐字符标签完全一致，差异 0，文件 SHA-256 也相同。组员统一评分器固定提交 `96ab5974672e842808df20cd007c4c737f90a790` 的评分为 Micro F1 **89.3501205%**（TP=21503、FP=3051、FN=2075），对应参考 89.3501%。见 [复现摘要](reproduction_dev/reproduction_summary.json)、[逐标签比较](reproduction_dev/prediction_comparison.json) 和 [统一评分](reproduction_dev/unified_score/20261023T233622327709_iyp6tklb/evaluation.json)。

请先读 [完整复现步骤、资源表和安装说明](reproduce/README.md)，再由模型负责人私下交付 PRIVATE 资产包。该包已准备但尚未发送，没有公开权重下载地址。GitHub ZIP 不含权重、原始数据或敏感原文；资产清单与哈希见 [required_assets.json](model/required_assets.json)。完整 E5 已含模型状态，不需要 pretrained/model.safetensors；本轮在仅有 pretrained/config.json 的独立根下验证成功。

冻结入口需要可用 CUDA，无 CPU 推理回退。原机 Windows x64、Python 3.13.5、Torch 2.14.1+cu132／CUDA 13.2、Transformers 5.20.1、Tokenizers 0.23.3；版本锁与实际成功环境一致，见 [环境检查](evidence/environment.json)。异机先通过环境检查，再按说明准备资产，另存路径配置，完整执行“新推理 → 校验新文件 → 统一评分新文件 → 与旧预测逐标签比较”。

dev 有 Gold，仅在推理后的统一评分读取。test 无 Gold，没有 test 成绩；dev/test 不可互相替代。本轮没有训练更新、参数修改、Gold 解码修正或推理后 BIO 修复。

完整新增实际命令、环境、配置、输入身份、起止时间、退出码和日志见 [reproduction_dev/logs](reproduction_dev/logs/new_dev_inference.execution.json)。文件清单和校验结果见 [file_hashes.json](evidence/file_hashes.json)、[package_validation.json](evidence/package_validation.json)。
