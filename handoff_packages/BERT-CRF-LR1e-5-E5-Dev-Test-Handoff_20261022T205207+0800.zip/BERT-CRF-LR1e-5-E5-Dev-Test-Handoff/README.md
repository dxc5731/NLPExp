# BERT-CRF 第三轮冻结模型 dev/test 交接包

版本 1.0，生成时间 2026-10-22T21:04:55.264548+08:00。用途：交给评估成员独立读取、校验和后续评分。此包不是天池上传格式。

模型为第三轮 BERT-CRF（LR=1e-5，输出头 Dropout=0.1，最佳 Epoch=5，Seed=42），训练 Run ID `20261021T195736+0800_real_training_95abb833`。Checkpoint SHA-256：`e5ee6aaa8d4a00a4626553002aa9a63253a8ee0139463fec2bb41427bf391bed`。没有启用第四轮边界辅助头；最终输出为原有严格 BIO CRF Viterbi 解码，未人工改写。

| 划分 | 原始输入 | 对话 | 句子 | 运行 ID | 预测 | 校验 |
|---|---|---:|---:|---|---|---|
| dev | IMCS-V2_dev.json | 833 | 33267 | 20261022T205207+0800_frozen_e5_dev | [predictions_dev.json](dev/predictions_dev.json) | [PASS，退出码 0](dev/validation_dev.json) |
| test | IMCS-V2_test.json | 811 | 32935 | 20261022T205207+0800_frozen_e5_test | [predictions_test.json](test/predictions_test.json) | [PASS，退出码 0](test/validation_test.json) |

dev 有金标准，可供后续独立评估；本次推理只保留原始文本和 ID，没有将 Gold 输入模型。本包不计算效果指标。test 没有金标准，只交付真实预测，未计算或声称官方测试成绩。dev 与 test 是不同划分，不能互相替代。PASS 只证明格式、ID、字符长度、BIO 及输入身份契约通过，不证明识别质量。

两份预测为 UTF-8 无 BOM 的双层原始 ID → BIO 字符串，标签用单个 ASCII 空格分隔；按 Python Unicode 码点一字符一标签。原文未清洗或归一化；CLS/SEP/PAD 不输出；没有截断、补 O 或 BIO 修复。dev/test 最长实际 Token 数分别为 201/197，均在 256 上限内。

完整运行记录见 [dev/run_info.json](dev/run_info.json)、[test/run_info.json](test/run_info.json)，分别附实际配置、命令、计时范围、环境、日志和输出哈希。两次均为 FP32、Batch Size=16；模型状态推理前后完全一致，反向传播及优化器更新均为 0。

训练源码 revision 为 `f15da70b09dd0d7e1a3946f53bf346146ea5db2f`（当时配置未跟踪；完整配置及哈希已保留）。推理时仓库 revision 为 `20afc6c35f88f22c1a1d883086b187a57e800a54`；新推理适配器和校验器未单独提交，已将实际代码及哈希完整放入 [reproduce](reproduce/README.md)。运行模型代码直接来自逐文件验证的第三轮源码快照，不是当前第四轮源码。详见 [代码身份](reproduce/code_identity.json) 和 [训练来源](model/training_provenance.json)。

权重未随包公开，受控位置与 SHA-256 见 [checkpoint_reference.json](model/checkpoint_reference.json)。原始数据、完整权重、Optimizer/RNG、敏感训练日志和逐句调试数据均排除；负责人提供受控输入后按 [复现说明](reproduce/README.md) 执行。原始训练日志本地位置和哈希已记录，包内仅有安全的开始/完成事件摘录。

校验器与 24 项契约测试随包；101 项项目回归测试通过。首次 unittest 未发现原项目的 pytest 用例、首次 dev 初始化导入错误及修正，均在 [测试与修正记录](evidence/tests_and_corrections.json) 如实保留。错误发生于模型加载前，未生成预测或更新权重。

完整文件清单及哈希见 [file_hashes.json](evidence/file_hashes.json)，打包前检查见 [package_validation.json](evidence/package_validation.json)。ZIP 生成后另行逐字节复核，ZIP 自身哈希与远端发布证据保存在发布方本地完成记录，以避免自引用哈希。
