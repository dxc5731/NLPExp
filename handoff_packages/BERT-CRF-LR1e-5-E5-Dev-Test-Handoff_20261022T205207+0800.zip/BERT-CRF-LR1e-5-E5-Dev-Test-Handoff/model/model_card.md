# 冻结模型卡

中文医疗五类 NER：Symptom、Drug、Drug_Category、Medical_Examination、Operation。BERT-base-chinese → offset_share_unique_v1 字符表示 → Dropout 0.1 → Linear 11 类 → 严格 BIO CRF。LR=1e-5、FP32、Seed=42，第三轮 Epoch 5。无边界辅助分支。

训练仅使用官方 train 的固定内部划分；内部验证选模，不使用官方 dev/test 选模。Checkpoint 身份、来源和受控位置见 checkpoint_reference.json、training_provenance.json。本包两次推理均不训练、不反向传播、不加载优化器；仅加载模型参数，严格核对原 Checkpoint 模型/训练配置身份。

数据具有医疗领域限制；结构校验不等于临床或识别质量认证。test 无金标准，没有官方 test 成绩。
