"""Frozen snapshot inference. Only (dialogue_id, sentence_id, sentence) reach encoding."""
import argparse, hashlib, json, os, platform, random, subprocess, sys, time
from pathlib import Path
from datetime import datetime
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'src'))
os.environ.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',TOKENIZERS_PARALLELISM='false',CUBLAS_WORKSPACE_CONFIG=':4096:8')
def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(8*1024*1024),b''): h.update(b)
    return h.hexdigest()
def strict(raw):
    def pairs(items):
        d={}
        for k,v in items:
            if k in d: raise ValueError('duplicate_json_key')
            d[k]=v
        return d
    return json.loads(raw.decode('utf-8'),object_pairs_hook=pairs,parse_constant=lambda x:(_ for _ in ()).throw(ValueError('nonfinite_json')))
def save(p,v):
    with Path(p).open('x',encoding='utf-8',newline='\n') as f: json.dump(v,f,ensure_ascii=False,indent=2,allow_nan=False); f.write('\n')
def text_records(data):
    """Projection discards every annotation/clinical metadata field; no Gold access."""
    records=[]
    for did,dialogue in data.items():
        if not isinstance(did,str) or not did: raise ValueError('dialogue_id')
        seen=set()
        for item in dialogue['dialogue']:
            sid=item['sentence_id']; text=item['sentence']
            if not isinstance(sid,str) or not sid or sid in seen: raise ValueError('sentence_id')
            if not isinstance(text,str) or not text: raise ValueError('sentence_text')
            seen.add(sid); records.append((did,sid,text))
    return records
def encode(tokenizer,records,max_tokens):
    import torch
    from bert_crf.character_mapping import character_index,OFFSET_UNIT,MAPPING_POLICY
    encoded=[]
    for did,sid,text in records:
        e=tokenizer(text,add_special_tokens=True,truncation=False,return_offsets_mapping=True,return_special_tokens_mask=True)
        if len(e['input_ids'])>max_tokens: raise ValueError(f'length_limit: {did}/{sid}')
        character_index(torch.tensor([e['offset_mapping']],dtype=torch.long),torch.tensor([e['attention_mask']],dtype=torch.long),torch.tensor([len(text)],dtype=torch.long),torch.tensor([e['special_tokens_mask']],dtype=torch.bool),offset_unit=OFFSET_UNIT,policy=MAPPING_POLICY)
        encoded.append(e)
    return encoded
def batch_inputs(tokenizer,records,encoded,device):
    import torch
    from bert_crf.character_mapping import OFFSET_UNIT,MAPPING_POLICY
    t=max(len(e['input_ids']) for e in encoded); lengths=torch.tensor([len(r[2]) for r in records],dtype=torch.long,device=device)
    ids=torch.full((len(records),t),tokenizer.pad_token_id,dtype=torch.long,device=device)
    attention=torch.zeros_like(ids); types=torch.zeros_like(ids)
    offsets=torch.zeros((len(records),t,2),dtype=torch.long,device=device)
    special=torch.ones_like(ids,dtype=torch.bool)
    for row,e in enumerate(encoded):
        n=len(e['input_ids']); ids[row,:n]=torch.tensor(e['input_ids'],device=device)
        attention[row,:n]=1; offsets[row,:n]=torch.tensor(e['offset_mapping'],device=device)
        special[row,:n]=torch.tensor(e['special_tokens_mask'],dtype=torch.bool,device=device)
        if 'token_type_ids' in e: types[row,:n]=torch.tensor(e['token_type_ids'],device=device)
    mask=torch.arange(int(lengths.max()),device=device)[None,:]<lengths[:,None]
    return {'input_ids':ids,'attention_mask':attention,'token_type_ids':types,'character_mask':mask,
        'mapping':{'offsets':offsets,'attention_mask':attention,'character_lengths':lengths,'special_tokens_mask':special,'offset_unit':OFFSET_UNIT,'policy':MAPPING_POLICY}}
def state_hash(model):
    h=hashlib.sha256()
    for name,tensor in sorted(model.state_dict().items()):
        h.update(name.encode()); h.update(tensor.detach().cpu().contiguous().numpy().tobytes())
    return h.hexdigest()
def main():
    p=argparse.ArgumentParser(); p.add_argument('--config',required=True); p.add_argument('--project-root',required=True); p.add_argument('--output',required=True)
    a=p.parse_args(); tick=time.perf_counter(); started=datetime.now().astimezone().isoformat()
    import torch, transformers, numpy as np
    from transformers import AutoTokenizer,BertConfig,BertModel
    from bert_crf.config import ModelConfig
    from bert_crf.config import configure_runtime
    from bert_crf.training_config import TrainingConfig
    from bert_crf.model import CharacterBertCRF,BertEncoder
    from bert_crf.character_mapping import OffsetCharacterAdapter
    from bert_crf.data_adapter import verify_tokenizer_coordinates
    from bert_crf.checkpoint import load_checkpoint_model
    cfg=strict(Path(a.config).read_bytes()); root=Path(a.project_root).resolve(); out=Path(a.output).resolve(); out.mkdir(parents=True,exist_ok=True)
    formal=strict((HERE/'training_config.json').read_bytes()); mc=ModelConfig(**formal['model']); tc=TrainingConfig(**formal['training'])
    assert cfg['checkpoint_sha256']==sha(root/cfg['checkpoint'])
    assert cfg['training_config_sha256']==sha(HERE/'training_config.json')
    for name,expected in cfg['snapshot_files'].items(): assert sha(HERE/name)==expected,name
    for name,expected in formal['inputs']['tokenizer']['files'].items(): assert sha(root/formal['inputs']['tokenizer']['path']/name)==expected
    configure_runtime(mc)
    tokenizer=AutoTokenizer.from_pretrained(root/formal['inputs']['tokenizer']['path'],use_fast=True,local_files_only=True)
    coordinate=verify_tokenizer_coordinates(tokenizer)
    raw=(root/cfg['source']).read_bytes(); assert hashlib.sha256(raw).hexdigest()==cfg['source_sha256']
    records=text_records(strict(raw)); del raw
    assert len(set(r[0] for r in records))==cfg['expected_dialogues'] and len(records)==cfg['expected_sentences']
    encoded=encode(tokenizer,records,cfg['max_tokens'])
    print(json.dumps({'event':'input_contract_pass','split':cfg['split'],'sentences':len(records),'max_tokens':max(len(e['input_ids']) for e in encoded),'gold_fields_projected_out':True}),flush=True)
    bc=BertConfig.from_json_file(root/formal['inputs']['pretrained']['path']/'config.json')
    model=CharacterBertCRF(mc,BertEncoder(BertModel(bc,add_pooling_layer=False)),OffsetCharacterAdapter()).to('cuda')
    state=load_checkpoint_model(root/cfg['checkpoint'],model,cfg['model_identity'],tc.to_dict())
    assert state['epoch']==5 and state['best_epoch']==5
    assert not any('boundary' in n or 'start_head' in n or 'end_head' in n for n,_ in model.named_parameters())
    model.eval(); before=state_hash(model); torch.cuda.reset_peak_memory_stats()
    predictions={r[0]:{} for r in records}; batches=0
    with torch.inference_mode():
        for start in range(0,len(records),cfg['batch_size']):
            rows=records[start:start+cfg['batch_size']]
            inputs=batch_inputs(tokenizer,rows,encoded[start:start+cfg['batch_size']],'cuda')
            assert 'character_labels' not in inputs
            output=model(**inputs,decode=True); assert output['loss'] is None
            for (did,sid,text),path in zip(rows,output['paths'],strict=True):
                assert len(path)==len(text)
                predictions[did][sid]=' '.join(mc.labels[i] for i in path)
            batches+=1
            if batches%500==0: print(json.dumps({'event':'progress','sentences':min(start+cfg['batch_size'],len(records))}),flush=True)
    torch.cuda.synchronize(); after=state_hash(model); assert before==after
    assert all(p.grad is None for p in model.parameters())
    assert sha(root/cfg['checkpoint'])==cfg['checkpoint_sha256']
    pred=out/f"predictions_{cfg['split']}.json"; save(pred,predictions)
    ended=datetime.now().astimezone().isoformat(); elapsed=time.perf_counter()-tick
    result={'run_id':cfg['run_id'],'split':cfg['split'],'started_at':started,'ended_at':ended,'inference_elapsed_seconds':elapsed,
       'timing_scope':'includes imports, input/hash checks, tokenization, model/checkpoint loading, CUDA forward+CRF decode, parameter identity checks and prediction writing; excludes training and independent validation',
       'prediction':{'file':pred.name,'sha256':sha(pred),'bytes':pred.stat().st_size},'dialogues':len(predictions),'sentences':len(records),'characters':sum(len(r[2]) for r in records),'batches':batches,'max_tokens_observed':max(len(e['input_ids']) for e in encoded),
       'checkpoint_sha256':cfg['checkpoint_sha256'],'state_hash_before':before,'state_hash_after':after,'optimizer_steps':0,'backward_calls':0,'auxiliary_head_enabled':False,'gold_supplied_to_model':False,'coordinate_probe':coordinate,
       'device':{'type':'cuda','name':torch.cuda.get_device_name(0),'total_bytes':torch.cuda.get_device_properties(0).total_memory,'peak_allocated_bytes':torch.cuda.max_memory_allocated(),'peak_reserved_bytes':torch.cuda.max_memory_reserved(),'cpu':platform.processor()},
       'environment':{'python':sys.version,'pytorch':torch.__version__,'transformers':transformers.__version__,'numpy':np.__version__,'cuda':torch.version.cuda,'cudnn':torch.backends.cudnn.version(),'os':platform.platform()},
       'inference_command':subprocess.list2cmdline([sys.executable,'-u','-X','utf8',str(Path(__file__).resolve()),*sys.argv[1:]]),'inference_working_directory':str(Path.cwd()),'exceptions':[]}
    save(out/'inference_result.json',result); print(json.dumps(result,ensure_ascii=False),flush=True)
if __name__=='__main__': main()
