# 推理与校验复现

src/bert_crf 为第三轮实际训练快照的逐字节副本。training_source_manifest.json 是原训练完整清单；本包复制了全部模型源码及正式配置，没有复制历史测试/报告。code_identity.json 列出本包实际代码哈希及训练、推理两种 revision。infer.py 和独立 src/validate_predictions.py 为本次新增的交接适配代码，未修改训练逻辑。

Python 3.13.5、PyTorch 2.14.1+cu132、Transformers 5.20.1、Tokenizers 0.23.3；完整直接依赖见 requirements.lock.txt。原机使用 RTX 5060 Laptop GPU。原模型代码 configure_runtime 固定 Seed=42 和确定性 FP32，关闭 TF32/AMP。

受控输入由负责人提供：model/checkpoint_reference.json 指定的 Checkpoint、training_config.json 中对应哈希的本地 Tokenizer 和 pretrained/config.json、原始 dev/test JSON。后者可从固定哈希原始 ZIP 逐字节提取，原机保留于推理配置 source 指定位置。所有这些数据/权重不随包公开。推理从完整 E5 Checkpoint 加载模型状态，不需要重新训练或加载预训练权重本体。两份原始配置记录的是原机实际路径；异机复现需要将受控输入放入对应 project-root 相对路径，或另存路径适配配置并记录差异，不得改模型参数、哈希或字符映射。

从包根目录运行（将 Python、项目根及输出替换为实际位置；输出预测/结果文件须不存在）：

```powershell
python -u -X utf8 reproduce/infer.py --config dev/config/inference.json --project-root C:/userProgram/NLPexp --output C:/controlled/new_dev_output
python -u -X utf8 reproduce/infer.py --config test/config/inference.json --project-root C:/userProgram/NLPexp --output C:/controlled/new_test_output
python -X utf8 reproduce/src/validate_predictions.py --data C:/controlled/IMCS-V2_dev.json --predictions dev/predictions_dev.json --split dev --archive C:/controlled/IMCS-V2-NER.zip --official --report C:/controlled/new_validation_dev.json
python -X utf8 reproduce/src/validate_predictions.py --data C:/controlled/IMCS-V2_test.json --predictions test/predictions_test.json --split test --archive C:/controlled/IMCS-V2-NER.zip --official --report C:/controlled/new_validation_test.json
```

在 reproduce 目录运行 `python -X utf8 -m unittest discover -s tests -v`：24 项标准库测试，不需要医疗数据或权重。校验器只检查结构，不评分、不修复预测；PASS/FAIL/NOT_RUN 对应退出码 0/1/2。test 金标项为不适用 NOT_RUN，不影响其他全部必需检查通过。

原机实际执行命令、工作目录、起止时间和退出码分别保存在 dev/logs、test/logs；run_info.json 单独记录不含独立校验的推理耗时，外部 execution.json 另含进程退出开销。完整原始训练日志在本地引用处，包内仅安全摘录。包内保留失败启动及修正记录。
