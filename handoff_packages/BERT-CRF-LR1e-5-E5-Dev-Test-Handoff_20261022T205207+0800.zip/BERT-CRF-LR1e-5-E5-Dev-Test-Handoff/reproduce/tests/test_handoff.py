import copy, importlib.util, json, sys, tempfile, unittest
from pathlib import Path
BASE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(BASE)); sys.path.insert(0,str(BASE/'src'))
import validate_predictions as v
from infer import text_records
class ContractTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.addCleanup(self.tmp.cleanup); self.root=Path(self.tmp.name)
        self.source={'d':{'dialogue':[{'sentence_id':'01','sentence':'甲 😀𠀀é','BIO_label':'O O B-Symptom I-Symptom O O'},{'sentence_id':'07','sentence':'乙','BIO_label':'B-Drug'}]}}
        self.pred={'d':{'01':'O O B-Symptom I-Symptom O O','07':'B-Drug'}}
    def run_case(self,source=None,pred=None,split='dev',**kw):
        a=self.root/'data.json'; b=self.root/'pred.json'
        a.write_text(json.dumps(source if source is not None else self.source,ensure_ascii=False),encoding='utf-8'); b.write_text(json.dumps(pred if pred is not None else self.pred,ensure_ascii=False),encoding='utf-8')
        return v.validate(a,b,split,**kw)
    def test_valid_unicode_ids(self): self.assertEqual(self.run_case()['status'],'PASS')
    def test_test_no_gold(self):
        for s in self.source['d']['dialogue']: del s['BIO_label']
        r=self.run_case(split='test'); self.assertEqual(r['status'],'PASS'); self.assertEqual(r['checks']['gold_structure']['status'],'NOT_RUN')
    def test_missing_sentence(self): del self.pred['d']['07']; self.assertEqual(self.run_case()['exit_code'],1)
    def test_extra_sentence(self): self.pred['d']['8']='O'; self.assertEqual(self.run_case()['status'],'FAIL')
    def test_changed_original_id(self): self.pred['d']['1']=self.pred['d'].pop('01'); self.assertEqual(self.run_case()['status'],'FAIL')
    def test_extra_dialogue(self): self.pred['x']={}; self.assertEqual(self.run_case()['status'],'FAIL')
    def test_length(self): self.pred['d']['07']='O O'; self.assertEqual(self.run_case()['status'],'FAIL')
    def test_invalid_label(self): self.pred['d']['07']='PAD'; self.assertEqual(self.run_case()['status'],'FAIL')
    def test_start_i(self): self.pred['d']['07']='I-Drug'; self.assertEqual(self.run_case()['status'],'FAIL')
    def test_cross_type_i(self):
        with self.assertRaises(ValueError): v.labels('B-Drug I-Symptom')
    def test_o_i(self):
        with self.assertRaises(ValueError): v.labels('O I-Symptom')
    def test_adjacent_same_type(self): self.assertEqual(v.labels('B-Drug B-Drug'),['B-Drug','B-Drug'])
    def test_separators(self):
        for t in [' O','O ','O  O','O\tO','O\nO','O\u00a0O']:
            with self.subTest(t=repr(t)),self.assertRaises(ValueError): v.labels(t)
    def test_duplicate_nested_key(self):
        with self.assertRaises(ValueError): v.strict_json(b'{"x":{"1":"O","1":"O"}}')
    def test_bom(self):
        with self.assertRaises(ValueError): v.strict_json(b'\xef\xbb\xbf{}')
    def test_nonfinite(self):
        with self.assertRaises(ValueError): v.strict_json(b'{"x":NaN}')
    def test_source_duplicate_sentence(self): self.source['d']['dialogue'].append(self.source['d']['dialogue'][0]); self.assertEqual(self.run_case()['status'],'FAIL')
    def test_gold_not_in_inference_projection(self):
        expected=text_records(self.source)
        for s in self.source['d']['dialogue']: s['BIO_label']=object(); s['other_gold']=object()
        self.assertEqual(text_records(self.source),expected)
    def test_inference_duplicate_rejected(self):
        self.source['d']['dialogue'].append(self.source['d']['dialogue'][0])
        with self.assertRaises(ValueError): text_records(self.source)
    def test_gold_length(self): self.source['d']['dialogue'][0]['BIO_label']='O'; self.assertEqual(self.run_case()['status'],'FAIL')
    def test_unavailable_archive_not_pass(self):
        r=self.run_case(official=True); self.assertEqual(r['checks']['archive_identity']['status'],'NOT_RUN'); self.assertNotEqual(r['status'],'PASS')
    def test_source_hash(self): self.assertEqual(self.run_case(expected_source_sha='0'*64)['status'],'FAIL')
    def test_read_failure(self): self.assertEqual(v.validate(self.root/'missing',self.root/'missing2','test')['status'],'FAIL')
    def test_source_split_mismatch(self):
        p=self.root/'IMCS-V2_dev.json'; p.write_text('{}')
        with self.assertRaises(ValueError): v.source_bytes(p,'test')
if __name__=='__main__': unittest.main()
