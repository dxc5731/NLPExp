"""Independent standard-library structural validator; never repairs or scores."""
import argparse, collections, hashlib, json, re, sys, zipfile
from pathlib import Path
LABELS={'O'}|{p+'-'+t for p in ('B','I') for t in ('Symptom','Drug','Drug_Category','Medical_Examination','Operation')}
ARCHIVE_SHA='84e34d2417b839d9fbe5c5f391e44de2a9b01bd5f31d576b8feccc78c1dfbc67'
SIZES={'dev':(833,33267),'test':(811,32935),'train':(2472,98529)}
def digest(raw): return hashlib.sha256(raw).hexdigest()
def strict_json(raw):
    if raw.startswith(b'\xef\xbb\xbf'): raise ValueError('UTF8_BOM')
    def pairs(items):
        out={}
        for k,v in items:
            if k in out: raise ValueError('DUPLICATE_KEY')
            out[k]=v
        return out
    def constant(v): raise ValueError('NONFINITE_JSON')
    return json.loads(raw.decode('utf-8'),object_pairs_hook=pairs,parse_constant=constant)
def labels(value):
    if not isinstance(value,str): raise ValueError('TAG_STRING_TYPE')
    if value=='': return []
    tags=value.split(' ')
    if any(not t or any(c.isspace() for c in t) for t in tags): raise ValueError('TAG_SEPARATOR')
    if any(t not in LABELS for t in tags): raise ValueError('UNKNOWN_LABEL')
    prev='O'
    for t in tags:
        if t.startswith('I-') and prev not in ('B-'+t[2:],t): raise ValueError('ILLEGAL_BIO')
        prev=t
    return tags
def source_bytes(path,split):
    path=Path(path); name=f'IMCS-V2_{split}.json'
    if path.is_dir():
        candidates=list(path.rglob(name))
        if len(candidates)!=1: raise ValueError('AMBIGUOUS_OR_MISSING_SOURCE')
        path=candidates[0]
    if path.suffix.lower()=='.zip':
        with zipfile.ZipFile(path) as z:
            names=[n for n in z.namelist() if Path(n).name==name]
            if len(names)!=1: raise ValueError('AMBIGUOUS_OR_MISSING_SOURCE')
            return z.read(names[0]),str(path)+'!'+names[0]
    if path.name.startswith('IMCS-V2') and path.name not in (name,'IMCS-V2-NER_test.json' if split=='test' else name): raise ValueError('SOURCE_SPLIT_MISMATCH')
    return path.read_bytes(),str(path)
def validate(data_path,prediction_path,split,*,archive=None,expected_source_sha=None,official=False):
    checks={}; errors=collections.Counter(); examples=[]
    def error(code,where=None):
        errors[code]+=1
        if len(examples)<30 and sum(x['code']==code for x in examples)<3: examples.append({'code':code,'location':where})
    def check(name,ok,detail=None,required=True): checks[name]={'status':'PASS' if ok else 'FAIL','required':required,'detail':detail}
    report={'schema_version':'handoff_validation_1.0','mode':'predictions','split':split,'checks':checks,'metrics_computed':False}
    try:
        raw,location=source_bytes(data_path,split); data=strict_json(raw)
        report['data']={'source':location,'source_sha256':digest(raw)}; check('source_read_and_strict_json',True)
    except Exception as exc:
        check('source_read_and_strict_json',False); error('SOURCE_READ_OR_JSON',type(exc).__name__+':'+str(exc)[:100]); data=None
    try:
        pred_raw=Path(prediction_path).read_bytes(); pred=strict_json(pred_raw)
        report['prediction']={'file':str(prediction_path),'sha256':digest(pred_raw),'bytes':len(pred_raw)}; check('prediction_utf8_strict_json_no_duplicates',True)
    except Exception as exc:
        check('prediction_utf8_strict_json_no_duplicates',False); error('PREDICTION_READ_OR_JSON',type(exc).__name__+':'+str(exc)[:100]); pred=None
    if archive:
        try:
            ar=Path(archive).read_bytes(); report['archive_sha256']=digest(ar)
            check('archive_identity',digest(ar)==ARCHIVE_SHA)
            if digest(ar)!=ARCHIVE_SHA: error('ARCHIVE_HASH')
            with zipfile.ZipFile(archive) as z:
                original=z.read(f'IMCS-V2-NER/IMCS-V2_{split}.json')
            check('source_matches_archive_member',data is not None and raw==original)
            if data is not None and raw!=original: error('SOURCE_ARCHIVE_MISMATCH')
        except Exception as exc: check('archive_identity',False); error('ARCHIVE_READ',type(exc).__name__)
    elif official: checks['archive_identity']={'status':'NOT_RUN','required':True,'reason':'archive not supplied'}
    if expected_source_sha:
        check('source_identity',data is not None and digest(raw)==expected_source_sha)
        if data is not None and digest(raw)!=expected_source_sha: error('SOURCE_HASH')
    source={}; counts={'dialogues':0,'sentences':0,'characters':0,'prediction_sentences':0,'fully_checked_sentences':0}
    if data is not None:
        if not isinstance(data,dict): error('SOURCE_ROOT_TYPE'); check('source_structure',False)
        else:
            counts['dialogues']=len(data)
            for did,d in data.items():
                if not isinstance(d,dict) or not isinstance(d.get('dialogue'),list): error('SOURCE_DIALOGUE_TYPE',did); continue
                source[did]={}
                for s in d['dialogue']:
                    counts['sentences']+=1
                    if not isinstance(s,dict) or not isinstance(s.get('sentence_id'),str): error('SOURCE_SENTENCE_TYPE',did); continue
                    sid=s['sentence_id']
                    if sid in source[did]: error('DUPLICATE_SENTENCE_ID',[did,sid])
                    source[did][sid]=s
                    if not isinstance(s.get('sentence'),str): error('SOURCE_TEXT_MISSING',[did,sid])
                    else: counts['characters']+=len(s['sentence'])
            check('source_structure',not any(k.startswith('SOURCE_') or k=='DUPLICATE_SENTENCE_ID' for k in errors))
            if official:
                ok=(counts['dialogues'],counts['sentences'])==SIZES[split]; check('official_scale',ok,SIZES[split])
                if not ok: error('OFFICIAL_SCALE')
    if split=='test': checks['gold_structure']={'status':'NOT_RUN','required':False,'reason':'official test has no Gold; no quality score computed'}
    elif source:
        for did,rows in source.items():
            for sid,s in rows.items():
                try:
                    tags=labels(s.get('BIO_label'))
                    if len(tags)!=len(s['sentence']): raise ValueError('GOLD_LENGTH')
                except (ValueError,KeyError): error('GOLD_STRUCTURE',[did,sid])
        check('gold_structure','GOLD_STRUCTURE' not in errors)
    if source and pred is not None:
        if not isinstance(pred,dict): error('PREDICTION_ROOT_TYPE'); check('exact_id_sets',False)
        else:
            if set(pred)!=set(source): error('DIALOGUE_ID_SET')
            for did,rows in source.items():
                actual=pred.get(did)
                if not isinstance(actual,dict): error('PREDICTION_DIALOGUE_TYPE',did); continue
                counts['prediction_sentences']+=len(actual)
                if set(actual)!=set(rows): error('SENTENCE_ID_SET',did)
                for sid,s in rows.items():
                    if sid not in actual: continue
                    before=sum(errors.values())
                    try:
                        tags=labels(actual[sid])
                        if not isinstance(s.get('sentence'),str):
                            checks['character_lengths']={'status':'NOT_RUN','required':True,'reason':'source lacks original text'}
                        elif len(tags)!=len(s['sentence']): error('CHARACTER_LENGTH',[did,sid])
                    except ValueError as exc: error(str(exc),[did,sid])
                    if before==sum(errors.values()) and isinstance(s.get('sentence'),str): counts['fully_checked_sentences']+=1
            check('exact_id_sets',not any(k in errors for k in ('DIALOGUE_ID_SET','SENTENCE_ID_SET','PREDICTION_DIALOGUE_TYPE')))
            check('label_set_separator_and_bio',not any(k in errors for k in ('TAG_STRING_TYPE','TAG_SEPARATOR','UNKNOWN_LABEL','ILLEGAL_BIO')))
            if 'character_lengths' not in checks: check('character_lengths','CHARACTER_LENGTH' not in errors)
    else:
        for n in ('exact_id_sets','label_set_separator_and_bio','character_lengths'):
            checks.setdefault(n,{'status':'NOT_RUN','required':True,'reason':'unreadable or invalid dependency'})
    status='FAIL' if errors or any(c['status']=='FAIL' for c in checks.values()) else 'NOT_RUN' if any(c['required'] and c['status']=='NOT_RUN' for c in checks.values()) else 'PASS'
    report.update(status=status,exit_code={'PASS':0,'FAIL':1,'NOT_RUN':2}[status],counts=counts,error_counts=dict(errors),error_examples=examples)
    return report
def main():
    p=argparse.ArgumentParser(); p.add_argument('--data',required=True); p.add_argument('--predictions',required=True); p.add_argument('--split',choices=SIZES,required=True); p.add_argument('--report',required=True); p.add_argument('--archive'); p.add_argument('--expected-source-sha256'); p.add_argument('--official',action='store_true'); a=p.parse_args()
    report_path=Path(a.report).resolve(); source=Path(a.data).resolve(); pred=Path(a.predictions).resolve()
    if report_path in (source,pred) or (source.is_dir() and source in report_path.parents): p.error('report must not overwrite input or enter data directory')
    r=validate(a.data,a.predictions,a.split,archive=a.archive,expected_source_sha=a.expected_source_sha256,official=a.official)
    report_path.parent.mkdir(parents=True,exist_ok=True)
    with report_path.open('x',encoding='utf-8',newline='\n') as f: json.dump(r,f,ensure_ascii=False,indent=2,allow_nan=False); f.write('\n')
    print(json.dumps({'status':r['status'],'counts':r['counts'],'error_counts':r['error_counts']},ensure_ascii=False)); return r['exit_code']
if __name__=='__main__': sys.exit(main())
